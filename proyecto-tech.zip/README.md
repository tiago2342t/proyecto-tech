# Proyecto Predicción de Finca Raíz

Integrantes:
Ximena Gaibao
Juan Camilo Espinosa
Jaider Barrios
Santiago Higuita

Este es el final de Proyecto Tech 2
